import React from 'react'
import Layout from '../../components/Layout/Layout'
import UserMenu from '../../components/Layout/UserMenu'
import { useAuth } from '../../context/auth.js'
const Dashboard = () => {
  const [auth] = useAuth()
  return (
    <Layout title={"Dashboard - Pharmacy"}>
      <div className="container-fluid">
        <div className="row">
          <div className="col-md-3">
            <UserMenu />
          </div>
          <div className="col-md-9 mt-5">
            <div className="card" style={{width: '18rem'}}>
              <div className="card-body">
                <h5 className="card-title">{auth?.user?.name}</h5>
                <h5 className="card-title">{auth?.user?.email}</h5>
                <h5 className="card-title">{auth?.user?.phone}</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default Dashboard

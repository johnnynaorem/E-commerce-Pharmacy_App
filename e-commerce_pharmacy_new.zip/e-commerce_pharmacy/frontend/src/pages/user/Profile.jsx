import React from 'react'
import Layout from '../../components/Layout/Layout'
import UserMenu from '../../components/Layout/UserMenu'

const UserProfile = () => {
  return (
    <Layout title={"Dashboard - User Profile"}>
      <div className="row">
        <div className="col-md-3">
          <UserMenu />
        </div>
        <div className="col-md-9 mt-4">
        <h1>Profile</h1>
        </div>
      </div>
    </Layout>
  )
}

export default UserProfile

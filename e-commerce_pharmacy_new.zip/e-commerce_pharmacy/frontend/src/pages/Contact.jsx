import React from 'react'
import Layout from '../components/Layout/Layout'

const Contact = () => {
  return (
    <Layout title={"Contact-U s"}>
      <h1>Contact</h1>
    </Layout>
  )
}

export default Contact

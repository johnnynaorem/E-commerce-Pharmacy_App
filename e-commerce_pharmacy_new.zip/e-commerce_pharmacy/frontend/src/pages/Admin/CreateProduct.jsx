import React, { useEffect, useState } from 'react'
import Layout from '../../components/Layout/Layout'
import AdminMenu from '../../components/Layout/AdminMenu'
import toast from 'react-hot-toast'
import axios from 'axios'
import { Select } from 'antd'
import { useNavigate } from 'react-router-dom'

const CreateProduct = () => {
  const navigate = useNavigate()
  const { Option } = Select
  const [categories, setCategories] = useState([])
  const [category, setCategory] = useState('')
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [price, setprice] = useState('')
  const [quantity, setQuantity] = useState('')
  const [shipping, setShipping] = useState('')
  const [image, setImage] = useState('')

  const getAllCategory = async () => {
    try {
      const {data} = await axios.get('http://localhost:8700/api/v1/category/get-category');
      if(data?.success) {
        setCategories(data?.category)
      }
    } catch (error) {
      console.log(error);
      toast.error("Something went wrong in getting category");
    }
  };

  useEffect(() => {
    getAllCategory();
  }, [])


  //handle create
  const handleCreate = async (e) => {
    e.preventDefault();
    try {
      const productDate = new FormData()
      productDate.append("name", name)
      productDate.append("description", description)
      productDate.append("price", price)
      productDate.append("quantity", quantity)
      productDate.append("image", image)
      productDate.append("category", category)
      const {data} = await axios.post('http://localhost:8700/api/v1/product/create-product', productDate)
      console.log(data)
      if(data?.success){
        toast.success(data?.message)
        navigate('/dashboard/admin/products')
      }else{
        toast.error(data.message)
      }
    } catch (error) {
      console.log(error);
      toast.error('Something Went Wrong')
    }
  }

  return (
    <Layout title={"Dashboard - Create Product"}>
      <div className="row w-100">
        <div className="col-md-3 mt-4">
          <AdminMenu />
        </div>
        <div className="col-md-9 mt-4">
          <h1>Create Product</h1>
          <div className="m-1 w-75">
            <Select className='form-select mb-3' variant={false} placeholder="Select a category" size='large' showSearch onChange={(value)=> setCategory(value)}>
              {categories?.map((c,i) => (
                <Option key={i} value={c._id}>{c.name}</Option>
              ))}
            </Select>
            <div className="mb-3">
              <label className='btn btn-secondary col-md-12'>
                {image? image.name : "Upload Image"}
                <input 
                  type='file'
                  name='image'
                  accept='image/*'
                  onChange={(e) => setImage(e.target.files[0])}
                  hidden
                />
              </label>
            </div>
            <div className="mb-3">
              {image && (
                <div className="text-center">
                  <img className='img img-responsive' src={URL.createObjectURL(image)} alt="" height={'200px'} />
                </div>
              )}
            </div>
            <div className="mb-3">
              <input 
                className='form-control'
                type="text"
                value={name}
                placeholder='Enter product name'
                onChange={(e) => setName(e.target.value)}
              />
            </div>
            <div className="mb-3">
              <textarea 
                className='form-control' rows={'3'}
                type="text-area"
                value={description}
                placeholder='Write a description'
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
            <div className="mb-3">
              <input 
                className='form-control'
                type="text"
                value={price}
                placeholder='Enter product price'
                onChange={(e) => setprice(e.target.value)}
              />
            </div>
            <div className="mb-3">
              <input 
                className='form-control'
                type="text"
                value={quantity}
                placeholder='Enter product quantity'
                onChange={(e) => setQuantity(e.target.value)}
              />
            </div>
            <div className="mb-3">
              <Select
                className='form-select mb-3'
                bordered={false}
                size='large'
                showSearch
                value={shipping}
                onChange={(value) => setShipping(value)}
              >
                <Option value='0'>No</Option>
                <Option value='1'>Yes</Option>
              </Select>
            </div>
            <div className="mb-3">
              <button className='btn btn-primary' onClick={handleCreate}>CREATE PRODUCT</button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  )
}

export default CreateProduct

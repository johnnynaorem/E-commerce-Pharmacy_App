import React, { useEffect, useState } from 'react'
import Layout from '../../components/Layout/Layout'
import AdminMenu from '../../components/Layout/AdminMenu'
import toast from 'react-hot-toast'
import axios from 'axios'
import { Select } from 'antd'
import { useNavigate, useParams } from 'react-router-dom'

const UpdateProduct = () => {
  const navigate = useNavigate()
  const params = useParams()
  const { Option } = Select
  const [categories, setCategories] = useState([])
  const [category, setCategory] = useState('')
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState('')
  const [quantity, setQuantity] = useState('')
  const [shipping, setShipping] = useState('')
  const [image, setImage] = useState('')
  const [id, setId] = useState('')

  //get single product

  const getSingleProduct = async () => {
    try {
      const {data} = await axios.get(`http://localhost:8700/api/v1/product/get-product/${params.slug}`)
      setCategory(data.product.category._id)
      setName(data.product.name)
      setDescription(data.product.description)
      setPrice(data.product.price)
      setPrice(data.product.price)
      setQuantity(data.product.quantity)
      setShipping(data.product.shipping)
      setId(data.product._id)
    } catch (error) {
      console.log(error);
      toast.error('Something when wrong in getting product');
    }
  }
  useEffect(() => {
    getSingleProduct();
  }, [])
  console.log(category)
  const getAllCategory = async () => {
    try {
      const {data} = await axios.get('http://localhost:8700/api/v1/category/get-category');
      if(data?.success) {
        setCategories(data?.category)
      }
    } catch (error) {
      console.log(error);
      toast.error("Something went wrong in getting category");
    }
  };
  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const productDate = new FormData()
      productDate.append("name", name)
      productDate.append("description", description)
      productDate.append("price", price)
      productDate.append("quantity", quantity)
      image && productDate.append("image", image)
      productDate.append("category", category)
      const {data} = await axios.put(`http://localhost:8700/api/v1/product/update-product/${id}`, productDate)
      if(data?.success){
        toast.success(data?.message)
        navigate('/dashboard/admin/products')
      }else{
        toast.error(data.message)
      }
    } catch (error) {
      console.log(error);
      toast.error('Something Went Wrong')
    }
  }

  const handleDelete = async (e) => {
    e.preventDefault();
    try {
      const {data} = await axios.delete(`http://localhost:8700/api/v1/product/product-delete/${id}`)
      if(data?.success){
        toast.success(data?.message)
        navigate('/dashboard/admin/products')
      }else{
        toast.error(data.message)
      }
    } catch (error) {
      console.log(error);
      toast.error('Something Went Wrong')
    }
  }

  useEffect(() => {
    getAllCategory();
  }, [])


  return (
    <Layout title={`Dashboard - Update Product`}>
    <div className="row w-100">
      <div className="col-md-3 mt-4">
        <AdminMenu />
      </div>
      <div className="col-md-9 mt-4">
        <h1>Update Product</h1>
        <div className="m-1 w-75">
          <Select className='form-select mb-3' variant={false} placeholder="Select a category" size='large' showSearch onChange={(value)=> setCategory(value)} value={category}>
            {categories?.map((c,i) => (
              <Option key={i} value={c._id}>{c.name}</Option>
            ))}
          </Select>
          <div className="mb-3">
            <label className='btn btn-secondary col-md-12'>
              {image? image.name : "Upload Image"}
              <input 
                type='file'
                name='image'
                accept='image/*'
                onChange={(e) => setImage(e.target.files[0])}
                hidden
              />
            </label>
          </div>
          <div className="mb-3">
            {image ? (
              <div className="text-center">
                <img className='img img-responsive' src={URL.createObjectURL(image)} alt="" height={'200px'} />
              </div>
            ) : (
              <div className="text-center">
                <img className='img img-responsive' src={`http://localhost:8700/api/v1/product/product-image/${id}`} alt="" height={'200px'} />
              </div>
            )}
          </div>
          <div className="mb-3">
            <input 
              className='form-control'
              type="text"
              value={name}
              placeholder='Enter product name'
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <textarea 
              className='form-control' rows={'3'}
              type="text-area"
              value={description}
              placeholder='Write a description'
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <input 
              className='form-control'
              type="text"
              value={price}
              placeholder='Enter product price'
              onChange={(e) => setPrice(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <input 
              className='form-control'
              type="text"
              value={quantity}
              placeholder='Enter product quantity'
              onChange={(e) => setQuantity(e.target.value)}
            />
          </div>
          <div className="mb-3">
            <Select
              className='form-select mb-3'
              variant={false}
              size='large'
              showSearch
              value={shipping? 'Yes': 'No'}
              onChange={(value) => setShipping(value)}
            >
              <Option value='0'>No</Option>
              <Option value='1'>Yes</Option>
            </Select>
          </div>
          <div className="mb-3 d-flex">
            <button className='btn btn-primary mx-1' onClick={handleUpdate}>UPDATE PRODUCT</button>
            <button className='btn btn-danger mx-1' onClick={handleDelete}>DELETE PRODUCT</button>
          </div>
        </div>
      </div>
    </div>
  </Layout>
  )
}

export default UpdateProduct

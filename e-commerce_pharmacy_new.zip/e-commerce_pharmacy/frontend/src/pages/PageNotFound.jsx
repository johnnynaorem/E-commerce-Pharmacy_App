import React from 'react'
import Layout from '../components/Layout/Layout'

const PageNotFound = () => {
  return (
    <Layout title={"go back page not found"}>
      <h1>404</h1>
      <p>Page not found</p>
    </Layout>
  )
}

export default PageNotFound

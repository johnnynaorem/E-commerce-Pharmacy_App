import React from 'react'
import Layout from '../components/Layout/Layout'

const Category = () => {
  return (
    <Layout title={"Category"}>
      <h1>Category</h1>
    </Layout>
  )
}

export default Category

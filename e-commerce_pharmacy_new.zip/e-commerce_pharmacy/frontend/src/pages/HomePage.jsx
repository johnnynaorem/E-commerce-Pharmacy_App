import React, { useEffect, useState } from "react";
import Layout from "../components/Layout/Layout";
import { useAuth } from "../context/auth";
import toast from "react-hot-toast";
import axios from "axios";
import {Checkbox} from 'antd'
import InfiniteScroll from "react-infinite-scroll-component";

const HomePage = (props) => {
  const [auth, setAuth] = useAuth();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [checked, setChecked] = useState([]);
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(false)

  //get Total count
  const getTotal = async () => {
    try {
      const { data } = await axios.get(
        "http://localhost:8700/api/v1/product/product-count"
      );
      setTotal(data.total);
    } catch (error) {
      console.log(error);
      toast.error("Something went wrong in getting products");
    }
  };
  console.log(total)

  //get products List
  const getProductsList = async () => {
    try {
      props.setProgress(10)
      setLoading(true)
      const { data } = await axios.get(
        `http://localhost:8700/api/v1/product/product-list/${page}`
      );
      props.setProgress(30)
      setLoading(false)
      props.setProgress(80)
      setProducts(data.products);
      props.setProgress(100)
    } catch (error) {
      setLoading(false)
      console.log(error);
      toast.error("Something went wrong in getting products");
    }
  };

   //get products
   const getAllProducts = async () => {
    try {
      const { data } = await axios.get(
        "http://localhost:8700/api/v1/product/get-products"
      );
      setProducts(data.products);
    } catch (error) {
      console.log(error);
      toast.error("Something went wrong in getting products");
    }
  };
  useEffect(() => {
    // if(!checked.length) getAllProducts();
    if(!checked.length) getProductsList();
  }, []);

  useEffect(() => {
    if(checked.length) filterProduct();
  }, [checked]);

  //get Category
  const getAllCategory = async () => {
    try {
      const { data } = await axios.get(
        "http://localhost:8700/api/v1/category/get-category"
      );
      setCategories(data.category);
    } catch (error) {
      console.log(error);
      toast.error("Something went wrong in getting products");
    }
  };
  useEffect(() => {
    getAllCategory();
    getTotal()
  }, []);

  //filter by category
  const handleFilter = (value, id) => {
    let all = [...checked];
    if(value){
      all.push(id)
    }else {
      all = all.filter(i => i !== id)
    }
    setChecked(all)
    if(all.length===0)getProductsList()
  }

  //get Filtered products
  const filterProduct = async () => {
    try {
      props.setProgress(10)
      const {data} = await axios.post('http://localhost:8700/api/v1/product/filter', {checked});
      props.setProgress(30)
      setProducts(data.product)
      props.setProgress(80)
      props.setProgress(100)
      } catch (error) {
      console.log(error)
      toast.error('Something went wrong in filter product')
    }
  }

  //load more
  const loadMore = async () => {
    try {
      props.setProgress(10)
      setLoading(true)
      const {data} = await axios.get(`http://localhost:8700/api/v1/product/product-list/${page+1}`);
      props.setProgress(30)
      setLoading(false)
      props.setProgress(80)
      setProducts([...products, ...data?.products])
      props.setProgress(100)
      } catch (error) {
      setLoading(false)
      console.log(error)
      toast.error('Something went wrong in filter product')
    }
  }
  useEffect(() => {
    if(page === 1) return;
    loadMore()
  }, [page])
  

  return (
    <Layout title={"Admin - All Products"}>
      <div className="container-fluid">
        <div className="row mt-3">
          <div className="col-md-3">
            <h4 className="text-center">Filter By Category</h4>
            <div className="d-flex flex-column">
              {categories.map(c => (
                <Checkbox key={c._id} onChange={(e) => {handleFilter(e.target.checked, c._id)}}>
                  {c.name}
                </Checkbox>
              ))}
            </div>
          </div>
          <div className="col-md-9">
            {JSON.stringify(checked, null,4)}
            <h1 className="text-center">All Products</h1>
            <InfiniteScroll
              dataLength={products.length}
              next={loadMore}
              hasMore={!checked.length?products.length !== total:''}
              // hasMore={products.length !== total}
              loader={<p>Loading...</p>}
        >
            <div className="d-flex flex-wrap gap-3">
              {products?.map((p) => (
                    <div className="card" style={{width: '18rem'}}>
                      <img src={`http://localhost:8700/api/v1/product/product-image/${p._id}`} className="card-img-top" alt="..." />
                      <div className="card-body">
                        <h5 className="card-title">{p.name}</h5>
                        <p className="card-text">{p.description.substring(0,30)}...</p>
                        <p className="card-text">{p.price}</p>
                        {p.quantity>0?<p className="card-text">Stock: {p.quantity}</p>:<p className="card-text" style={{color: 'red'}}>Out of stock</p>}
                        <a href="#" class="btn btn-primary ms-1">More Details</a>
                        <a href="#" class="btn btn-secondary ms-1">Add to Cart</a>
                      </div>
                    </div>
              ))}
            </div>
            </InfiniteScroll>
            {/* <div className="m-2 p-3">
            {products && products.length < total && (
              <button className="btn btn-warning" onClick={(e) => {
                // e.preventDefault();
                setPage(page+1)
              }}>
                {loading? "Loading...": "Load More"}
              </button>
              )}
            </div> */}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default HomePage;

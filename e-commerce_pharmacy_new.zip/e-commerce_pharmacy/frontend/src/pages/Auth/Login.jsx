import React, { useState } from 'react'
import axios from 'axios';
import Layout from '../../components/Layout/Layout'
import toast from 'react-hot-toast';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/auth';

const Login = () => {
  const navigate = useNavigate()
  const location = useLocation()
  const [credentials, setCredentials] = useState({email: "", password: ""});
  const [auth, setAuth] = useAuth();
  const handleOnChange = (event) => {
    setCredentials({...credentials, [event.target.name]: event.target.value})
  }
  const handleSubmit = async (event) => {
    event.preventDefault()
    try {
      const response = await axios.post("http://localhost:8700/api/v1/auth/login",{ email: credentials.email, password: credentials.password });
      if(response && response.data.success){
        toast.success(response.data && response.data.message);
        setAuth({
          ...auth,
          user: response.data.user,
          token: response.data.token
        })
        localStorage.setItem('auth', JSON.stringify(response.data))
        navigate( location.state || '/')
      }
      else{
        toast.error(response.data.message)
      }
    } catch (error) {
      console.log(error)
      toast.error("Something went wrong")
    }
  }
  return (
    <Layout title={"Login"}>
      <h3 className='text-center my-4'>Login page</h3>
      <form className='mx-auto' style={{maxWidth: '30%'}} onSubmit={handleSubmit}>
        <div className="mb-3">
          <input type="email" className="form-control" id="email" name='email' placeholder='Email' required onChange={handleOnChange}/>
        </div>
        <div className="mb-3">
          <input type="password" className="form-control" id="password" name='password' placeholder='Enter Password' required onChange={handleOnChange}/>
        </div>
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </Layout>
  )
}

export default Login

import React, { useState } from 'react'
import Layout from '../../components/Layout/Layout';
import toast from 'react-hot-toast';
import axios from "axios"
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const navigate = useNavigate()
  const [credentials, setCredentials] = useState({name: "", email: "", password: "", address: "", phone: ""});
  const handleOnChange = (event) => {
    setCredentials({...credentials, [event.target.name]: event.target.value})
  }
  const handleSubmit = async (event) => {
    event.preventDefault()
    try {
      const response = await axios.post("http://localhost:8700/api/v1/auth/register",{name: credentials.name, email: credentials.email, password: credentials.password, address: credentials.email, phone: credentials.phone});
      if(response && response.data.success){
        toast.success(response.data && response.data.message);
        navigate('/login')
      }
      else{
        toast.error(response.data.message)
      }
    } catch (error) {
      console.log(error)
      toast.error("Something went wrong")
    }
  }
  return (
    <Layout>
      <h3 className='text-center my-4'>Register page</h3>
      <form className='mx-auto' style={{maxWidth: '30%'}} onSubmit={handleSubmit}>
        <div className="mb-3">
          <input type="text" className="form-control" id="name" name='name' placeholder='Name' required onChange={handleOnChange}/>
        </div>
        <div className="mb-3">
          <input type="email" className="form-control" id="email" name='email' placeholder='Email' required onChange={handleOnChange}/>
        </div>
        <div className="mb-3">
          <input type="password" className="form-control" id="password" name='password' placeholder='Enter Password' required onChange={handleOnChange}/>
        </div>
        <div className="mb-3">
          <input type="text" className="form-control" id="address" name='address' placeholder='Enter Address' required onChange={handleOnChange}/>
        </div>
        <div className="mb-3">
          <input type="text" className="form-control" id="phone" name='phone' placeholder='Enter Phone Number' required onChange={handleOnChange}/>
        </div>
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>

    </Layout>
  )
}

export default Register;
